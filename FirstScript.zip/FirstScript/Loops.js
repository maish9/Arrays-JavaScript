function Run(){

    var courses  = ["Applied","COMS","Physics","MATH","Stats"]
    
    console.log(courses.length-1);
        

//event handling
