

function Arrays(cours){

    var courses = cours;
    cours = ["Applied","COMS","Physics","MATH","Stats"];
     cours.forEach(function(item){

         return item;
     }); 
    
}
var returnItem = Arrays(2);
console.log(returnItem);
